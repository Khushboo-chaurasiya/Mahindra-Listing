import React, { useState, useEffect } from 'react'
import myData from './data.json';

function Notes() {
    return (
        <div className="container outerDiv">
            <p>
                <img className="headerImg" src={require("./images/bg-header-desktop.svg")} alt="Not found" />
            </p>
            <div className="container my-4" style={{ backgroundColor: "hsl(180, 52%, 96%)" }}>

                <div className="row">
                    <div className="col-md-12 mb-4 tableDiv">

                        {
                            myData.map(item => (
                                <table>
                                    <tbody>

                                        <tr key={item.id}>
                                            <td rowSpan="3" className="imgRow">
                                                
                                                <img src={require(`${item.logo}`)} width="55px" height="55px" alt="Not found" />
                                                
                                            </td>
                                            <td style={{ paddingTop: "1%" }}>
                                                <b className="title">{item.company}</b> {item.new && <span className="titleNew">NEW!</span>} {item.featured && <span className="titleFeatured">FEATURED</span>}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td className="position">{item.position}
                                            </td>
                                            <td className="languageTd">
                                                {item.languages.map(language => (
                                                    <span className="language" > {language} </span>
                                                ))}
                                            </td>

                                        </tr>
                                        <tr>
                                            <td className="lastRow">{item.postedAt} <span>.</span> {item.contract} <span>.</span> {item.location}  </td>
                                        </tr>
                                    </tbody>
                                </table>
                            ))
                        }



                    </div>


                </div>


                <hr />
            </div>
        </div>
    )
}

export default Notes
